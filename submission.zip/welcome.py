print("Welcome to Python development!")
